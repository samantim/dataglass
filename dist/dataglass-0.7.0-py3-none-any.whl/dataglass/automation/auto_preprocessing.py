from ..preprocessing import *
import pandas as pd
from typing import List

def get_datatypes(data: pd.DataFrame) -> List:
    # Drop all NaN values with to infer the column types correctly
    # data_copy = handle_missing_values_drop(data)
    data_copy = handle_missing_values_datatype_imputation(data, NumericDatatypeImputationMethod.MODE)

    # Datatype heuristic inference
    data_copy = convert_datatype_auto(data_copy)

    # Extract columns with specific types
    numeric_columns = []
    categorical_columns = []
    datetime_columns = []
    bool_columns = []

    data_types = data_copy.dtypes
    for col, dt in data_types.items():
        if pd.api.types.is_bool_dtype(dt):
            bool_columns.append(col)
        elif pd.api.types.is_datetime64_any_dtype(dt):
            datetime_columns.append(col)
        elif pd.api.types.is_numeric_dtype(dt):
            numeric_columns.append(col)
        else:
            categorical_columns.append(col)
    
    return data_types, numeric_columns, categorical_columns, datetime_columns, bool_columns


def calc_missing_ratio(data: pd.DataFrame, col: str) -> float:
    # Calculate the ratio of missing values
    return data[col].isna().sum()/len(data[col])


def auto_handle_missing_values(data: pd.DataFrame) -> pd.DataFrame:
    # Get datatypes of all columns
    data_types, numeric_columns, categorical_columns, datetime_columns, bool_columns = get_datatypes(data)

    # 1: Handle missing values of datetime columns
    # Missing values are imputed by 1900-01-01 timestamp
    for col in datetime_columns:
        if data[col].isna().sum() > 0:
            data[col] = data[col].fillna(pd.Timestamp(year=1900, month=1, day=1))

    # Datatype heuristic inference to unify all datetime formats
    data[datetime_columns] = convert_datatype_auto(data[datetime_columns])

    # 2: Handle categorical variables with more than 30% missing values
    for col in categorical_columns:
        missing_ratio = calc_missing_ratio(data, col)
        if missing_ratio >= 0.3:
            data[col] = data[col].fillna("Empty")
        else:
            data[col] = data[col].fillna(data[col].mode()[0])

    # 3: Impute bool values with False, as it is the safer value
    for col in bool_columns:
        data[col] = data[col].fillna(0)

    # 4: Handle numeric columns
    # Check if it is a time series data
    if len(datetime_columns) > 0:
        # If it is a time serie dataset
        for col in numeric_columns:
            missing_ratio = calc_missing_ratio(data, col)
            if missing_ratio <= 0.1:
                # Interpolation by time whould be smooth
                data[col] = handle_missing_values_adjacent_value_imputation(data[[datetime_columns[0], col]], AdjacentImputationMethod.INTERPOLATION_TIME, datetime_columns[0])[col]
            else:
                # Imputation by ffill and bfill is more reasonable (bfill is used to ensure that the first row is also imputed)
                data[col] = handle_missing_values_adjacent_value_imputation(data[[col]], AdjacentImputationMethod.FORWARD)
                data[col] = handle_missing_values_adjacent_value_imputation(data[[col]], AdjacentImputationMethod.BACKWARD)

    # If it is not a TS dataset or there are some NaN values remained from the TS related approaches
    for col in numeric_columns:
        skew = abs(data[col].skew())
        if skew < 1:
            data[col] = handle_missing_values_datatype_imputation(data[[col]], NumericDatatypeImputationMethod.MEAN)
        else:
            data[col] = handle_missing_values_datatype_imputation(data[[col]], NumericDatatypeImputationMethod.MODE)

    # This datatype change is necessary to reset datatypes to their own nature, because they may be changed unintentionally in interpolation
    for col in data.columns:
        data[col] = data[col].astype(data_types[col])

    return data

    



